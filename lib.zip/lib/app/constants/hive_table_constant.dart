class HiveTableConstant {
  HiveTableConstant._();

  static const int customerTableId = 0;
  static const String customerBox = 'customerBox';
}
